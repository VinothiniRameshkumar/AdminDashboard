import logo from './logo.svg';
import './App.css';
import Chart from './BarChart'
import Dyanamic from './Piechart'
import TableDb from './popup'
function App() {
  return (
      <div className="container">
      <Chart/>
      {/* <Dyanamic /> */}
      {/* <TableDb/> */}
      </div>
  
  );
}

export default App;
